///////////////////
// UI Typography //
///////////////////

"use strict";

$(document).ready(function(){
	
	/* Load Prettify */
	/**
	 * DEMO CODE
	 * These lines of code below are merely demo purposes. Build upon them and create your own
	 * Check documentation for usage
	 */
	prettyPrint();
});