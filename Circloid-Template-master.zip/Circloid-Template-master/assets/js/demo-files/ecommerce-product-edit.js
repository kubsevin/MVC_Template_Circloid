/////////////////////////////////////
// eCommerce Product Edit function //
/////////////////////////////////////

"use strict";

$(document).ready(function(){
	
	/* CKEditor */
	$(".ckeditor-enabled").ckeditor();
});